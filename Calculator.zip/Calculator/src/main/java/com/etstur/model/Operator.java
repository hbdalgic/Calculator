package com.etstur.model;

public enum Operator {
    ADD,
    SUBTRACT,
    DIVIDE,
    MULTIPLY
}
